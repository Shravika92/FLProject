import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-storelocator',
  templateUrl: './storelocator.component.html',
  styleUrls: ['./storelocator.component.css']
})
export class StorelocatorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
