import { Component, OnInit, Injectable } from '@angular/core';
import { CustomerServiceService } from '../customer-service.service';
import { Customer } from '../customer';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})


@Injectable({
  providedIn: 'root'
})

export class SignupComponent{

  cust: Customer;

  constructor(private router: Router, private userService:CustomerServiceService) { }

  ngOnInit() {
  }
  
  onSubmit(cust: Customer)
  {
    this.userService.createCustomerAccount(this.cust).subscribe(result=>{
    console.log(result);
    this.gotoCustomer();
  });
}

gotoCustomer()
{
  this.router.navigate(['/home']);
}
  cust_state: string[] = ["Andhra Pradesh","West Bengal","Telangana","Karnataka"];
  cust_city: string[] = ["Vizag","Kolkatta","Secunderabad","Bangalore"];

  newCustomer(cust_fname,cust_lname,cust_pwd,cust_phnum,cust_email,cust_addr,cust_city,cust_state,cust_zip){
    this.cust.cust_fname=cust_fname;
    this.cust.cust_lname=cust_lname;
    this.cust.cust_pwd=cust_pwd;
    this.cust.cust_phnum=cust_phnum;
    this.cust.cust_email=cust_email;
    this.cust.cust_addr=cust_addr;
    this.cust.cust_city=cust_city;
    this.cust.cust_state=cust_state;
    this.cust.cust_zip=cust_zip;
  this.onSubmit(this.cust);
  }
}
