package com.cg.customer.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.customer.bean.Customer123;
import com.cg.customer.dao.CustomerDao;
import com.cg.customer.exception.CustomerException;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerDao customerDao;
	
	@Override
	public List<Customer123> addCustomer(Customer123 cust) throws CustomerException {
		try {
			customerDao.save(cust);
			return customerDao.findAll();
		}
		catch(Exception ex)
		{
			throw new CustomerException("Check the details properly");
		}
	}
}
