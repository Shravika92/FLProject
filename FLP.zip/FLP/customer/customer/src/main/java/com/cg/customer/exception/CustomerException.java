package com.cg.customer.exception;

public class CustomerException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public CustomerException()
	{
		
	}
	public CustomerException(String msg)
	{
		super();
	}


}
